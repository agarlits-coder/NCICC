import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NCICC – North Central Indiana Cycling Club",
  description: "Ride the Rails. Grow the Community.",
  icons: [{ rel: "icon", url: "/favicon.ico" }],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
