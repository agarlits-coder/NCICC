import dynamic from "next/dynamic";

const NCICCApp = dynamic(() => import("../components/NCICCApp"), { ssr: false });

export default function Page() {
  return <NCICCApp />;
}
