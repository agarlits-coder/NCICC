# NCICC – North Central Indiana Cycling Club (MVP)

A Next.js + Tailwind + TypeScript site with an MVP landing page, mock leaderboard, and sections for trails, events, and sponsors. Framer Motion is used for subtle animations.

## Quick Start

```bash
# Install deps
npm install

# Run dev server
npm run dev

# Visit
http://localhost:3000
```

## Deploy (Vercel)

1. Create a GitHub repository and push this folder.
2. Go to https://vercel.com and import the repo.
3. Vercel builds automatically and gives you a live URL.

## Roadmap

- Strava OAuth + webhooks
- Verified on‑trail miles using trail geometry
- Interactive map with GPX overlays
- Team leaderboards, badges, and challenges
